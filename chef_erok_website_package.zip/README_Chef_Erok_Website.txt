CHEF EROK WEBSITE — QUICK START

1. Open chef_erok_website.html in a browser to preview the website.
2. Before publishing, open the HTML file in a text editor and find:
   const BUSINESS_EMAIL = 'YOUR_EMAIL_HERE';
   Replace YOUR_EMAIL_HERE with the email address where you want inquiries sent.
3. Replace the sample photos with your own food photos and artwork for a more authentic brand.
4. The website currently uses externally hosted Unsplash photos, so an internet connection is needed to display them.
5. The contact form opens an email draft; it does not send messages automatically or store customer submissions.
6. To make the site public, upload the HTML file to a web host or connect it to a domain. This file is a website, but it has not been published online.
